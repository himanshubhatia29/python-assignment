from rest_framework import serializers
from .models import Restrouter
class RestapiSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restrouter
        fields = "__all__"