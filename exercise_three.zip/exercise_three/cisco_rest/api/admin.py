from django.contrib import admin
from .models import Restrouter
# Register your models here.
admin.site.register(Restrouter)