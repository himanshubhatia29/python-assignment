from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.views.decorators.csrf import csrf_exempt
from .models import Restrouter

@api_view(["GET"])
@csrf_exempt
@permission_classes([IsAuthenticated])
def get_list(request):
    # user = request.user.id
    router_mgmt = Restrouter.objects.filter()
    serializer = RestapiSerializer(router_mgmt, many=True)
    return JsonResponse({'router': serializer.data}, safe=False, status=status.HTTP_200_OK)

@api_view(["POST"])
@csrf_exempt
@permission_classes([IsAuthenticated])
def add_router(request):
    payload = json.loads(request.body)
    # // user = request.user
    try:
        author = Author.objects.get(id=payload["author"])
        router = Restrouter.objects.create(
            sapId=payload["sapId"],
            loopBack=payload["loopBack"],
            hostName=payload["hostName"],
            macAddress=payload["macAddress"],
            # added_by=user,
            author=author
        )
        serializer = RestapiSerializer(router)
        return JsonResponse({'router': serializer.data}, safe=False, status=status.HTTP_201_CREATED)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(["PUT"])
@csrf_exempt
@permission_classes([IsAuthenticated])
def update_router(request, router_id):
    # user = request.user.id
    payload = json.loads(request.body)
    try:
        router = Restrouter.objects.filter(id=router_id)
        # returns 1 or 0
        router_item.update(**payload)
        router = Restrouter.objects.get(id=router_id)
        serializer = RestapiSerializer(router)
        return JsonResponse({'router': serializer.data}, safe=False, status=status.HTTP_200_OK)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(["DELETE"])
@csrf_exempt
@permission_classes([IsAuthenticated])
def delete_router(request, router_id):
    # user = request.user.id
    try:
        router = Restrouter.objects.get(id=router_id)
        router.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(["GET"])
@csrf_exempt
@permission_classes([IsAuthenticated])
def portalInfo(request):
    content = {"message": "This is a Cisco Router master Portal"}
    return JsonResponse(content)