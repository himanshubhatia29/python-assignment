from django.urls import include, path
from . import views

urlpatterns = [
  path('Info', views.portalInfo),
  path('getrouter', views.get_list),
  path('addrouter', views.add_router ),
  path('updaterouter/<int:router_id>', views.update_router),
  path('deleterouter/<int:router_id>', views.delete_router)
]