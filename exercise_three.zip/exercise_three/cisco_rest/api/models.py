from django.db import models
from django.conf import settings
from django.utils import timezone
# Create your models here.
class Restrouter(models.Model):
    id = models.AutoField("id",'id',primary_key=True)
    sapId=models.CharField('sapId','sapId',max_length=50,blank=False, null=False)
    hostName=models.CharField('hostName','hostName',max_length=50,blank=False, null=False,unique=True)
    loopBack=models.CharField('loopBack','loopBack',max_length=50,blank=False, null=False,unique=True)
    macAddress=models.CharField('macAddress','macAddress',max_length=50,blank=False, null=False)
    created_date = models.DateTimeField("Created At", auto_now_add=True)
