from django import forms
from .models import cisco_routers
class routerForm(forms.ModelForm):
    class Meta:
        model=cisco_routers
        fields = "__all__"