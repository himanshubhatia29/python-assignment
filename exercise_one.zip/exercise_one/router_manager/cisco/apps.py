from django.apps import AppConfig


class CiscoConfig(AppConfig):
    name = 'cisco'
