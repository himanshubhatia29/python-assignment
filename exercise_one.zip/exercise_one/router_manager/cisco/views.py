from django.shortcuts import render,redirect,get_object_or_404
from .models import cisco_routers
from .forms import routerForm
from django.views.generic import ListView,DetailView

# Create your views here.
class IndexView(ListView):
    template_name = 'cisco/index.html'
    context_object_name = 'router_list'

    def get_queryset(self):
        return cisco_routers.objects.all()        

class Routerdetailview(DetailView):
    model = cisco_routers
    template_name = 'cisco/router-detail.html'        


def create(request):
    if request.method == 'POST':
        form = routerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    form = routerForm()

    return render(request,'cisco/create.html',{'form': form})     


def edit(request, pk, template_name='cisco/edit.html'):
    routerdata = get_object_or_404(cisco_routers, pk=pk)
    form = routerForm(request.POST or None, instance=routerdata)
    if form.is_valid():
        form.save()
        return redirect('index')
    return render(request, template_name, {'form':form})
    
def delete(request,pk,template_name='cisco/confirm_delete.html'):
    routerdata = get_object_or_404(cisco_routers,pk=pk)
    if request.method == 'POST':
        routerdata.delete()
        return redirect('index')
    return render(request, template_name, {'object':routerdata})    