from django.db import models

# Create your models here.
class cisco_routers(models.Model):
    id = models.AutoField("id",'id',primary_key=True)
    sapId=models.CharField('sapId','sapId',max_length=50,blank=False, null=False)
    hostName=models.CharField('hostName','hostName',max_length=50,blank=False, null=False)
    loopBack=models.CharField('loopBack','loopBack',max_length=50,blank=False, null=False)
    macAddress=models.CharField('macAddress','macAddress',max_length=50,blank=False, null=False)
    createdAt = models.DateTimeField("Created At", auto_now_add=True)